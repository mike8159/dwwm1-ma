import React from "react";
import Product from "./Product";




export default class ShoppingCart extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return 

        <div>
            <Product/>
        </div>
        
}
}
