import React from "react";
import '../css/contact.css';

export default class Contact extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (



<p><img src="assets/contact.png"></img>
<br/><br/>
    <u>Pour toutes questions :</u> <br/><br/><br/><br/>
Vous pouvez nous contacter par email à l'adresse suivante : geekland.afci@gmail.com <br/><br/> ou <br/><br/><u> par voie postale :</u><br/><br/>12 rue
Anselme Saint Ouen paris 93400 <br/><br/><br/> ou<br/><br/><br/><u>par téléphone :</u> 07.50.25.33.99.<br/><br/><br/><br/>
Nos conseillers sont à votre écoute.<br/><br/><br/>
<u>Horaires d'ouvertures :</u> <br/><br/><br/> du lundi au samedi de 9h00 à 12h00,
et de 14h00 à 18h00.




</p>





        );





    }
}