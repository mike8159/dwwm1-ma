<?php

header('content-type: application/json');
header('Access-Control-Allow-Origin: *');

$conn = mysqli_connect('localhost', 'root', '', 'geekland');
mysqli_set_charset($conn, 'utf8');

if(!$conn) {
    die('not connect:'.mysqli_error($conn));

}
$request = mysqli_query($conn, 'select * from product_list');

$tableau = [];



while($res = mysqli_fetch_object($request)) {

    $tableau[] = $res;
        
}




echo json_encode($tableau, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);

mysqli_close($conn);

?>