<?php

// Connexion
include ('php/bd.connexion.php');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

function encode_to_json($mixed)
{
    $json = json_encode($mixed, JSON_NUMERIC_CHECK | JSON_UNESCAPED_UNICODE);
    // echo json_last_error_msg();
    return $json;
}

$rubric = null;
$type = null;
$req_string = null;
$category = null;

// check if rubric argument exists and is not empty
if (isset($_GET['rubric']) && !empty($_GET['rubric'])) {
    $rubric = $_GET['rubric'];
}

// send errror if rubric is not good
if ($rubric === null) {
    die('{"error":"no rubric selected"}');
}

// 
switch ($rubric) {
    case 'carousel-top-ventes-jeux-videos': // request 6 products for jeux videos carousel
        $req_string = 'SELECT * FROM product_list WHERE id = 1 OR id = 3 OR id = 7 OR id = 10 OR id = 11 OR id = 5 LIMIT 6';
        break;

    case 'carousel-top-ventes-mangas': // request 6 products for products mangas carousel
        $req_string = 'SELECT * FROM product_list WHERE  id = 47 OR id = 17 OR id = 44 OR id = 48 OR id = 46 OR id = 50 LIMIT 6';
        break;

        case 'carousel-top-ventes-produits-derives': // request 6 products for products figurines carousel
            $req_string = 'SELECT * FROM product_list WHERE id = 54 OR id = 52 OR id = 51 OR id = 18 OR id = 20 OR id = 19 LIMIT 6'; 
            break;
          
           

    case 'all': // all products
        $req_string = 'SELECT * FROM product_list';
        if (isset($_GET['type']) && !empty($_GET['type'])) {
            $type = $_GET['type'];
        }

        if ($type != null) {
            $req_string .= ' WHERE type="'.$type.'"';
            
        }
      
        if (isset($_GET['category']) && !empty($_GET['category'])) {
            $category = $_GET['category'];
        }

        if ($category != null) {
            $req_string .= ' and category="'.$category.'"';
            
        }
        
        
      
        // $_GET['type'];
        break;

       

        




    case 'news': // new products
        $req_string = 'SELECT * FROM product_list ORDER BY record_date DESC';
        break;

    case 'promotions': // products in promotion
        $req_string = 'SELECT * FROM product_list WHERE cut_price_percentage != 0';
        break;

    case 'product': // one product
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $req_string = 'SELECT * FROM product_list WHERE id=' . $_GET['id'];
        }
        break;
    case 'reviewlist': // list reviews
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $req_string = '
            SELECT opinions.id, date, opinion, name, star_count
            FROM opinions
            LEFT JOIN users ON user_id=users.id
            WHERE product_id=' . $_GET['id'];
        }
        break;

    default:
        $req_string = null;
}


if ($req_string === null) {
    die('{"error":"rubric ' . $rubric . ' don\'t exists"}');
}

// query database with request string
$req = mysqli_query($conn, $req_string);

// fetch all row to datas array
$datas = mysqli_fetch_all($req, MYSQLI_ASSOC);

// if (mysqli_errno($conn)) {
//     die($req_string . ' ' . encode_to_json(mysqli_error($conn)));
// }

echo encode_to_json($datas);
