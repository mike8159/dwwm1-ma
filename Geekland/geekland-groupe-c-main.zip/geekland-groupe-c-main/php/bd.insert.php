<?php
include('bd.connexion.php');
mysqli_query($conn, 'set names "utf8";');
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('B4B', 'videogames','fps','2022-02-24', 23.99,'Édité par Warner Bros, Back 4 Blood est le nouveau FPS coopératif avec des zombies de Rock Turtle Studios.', 10)";
$product1 = mysqli_query($conn, $sql);
if (!$product1) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST ( name, type, category,  date, price, description, inventory) VALUES ('BattleField', 'videogames','fps', '2022-04-10', 40.45,'Battlefield™ 2042 est un jeu de tir à la première personne qui marque le retour de la guerre totale emblématique de la franchise.', 3)";
$product2 = mysqli_query($conn, $sql);
if (!$product2) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('CallOfDuty', 'videogames','fps', '2021-11-05', 65.90,'Call of Duty: Vanguard est un jeu vidéo de tir à la première personne développé par Sledgehammer Games et édité par Activision, sorti le 5 novembre 2021 sur Microsoft Windows.', 59)";
$product3 = mysqli_query($conn, $sql);
if (!$product3) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ( 'DyingLight2', 'videogames', 'action', '2021-11-14', 29.50, 'Dying Light 2 Stay Human est un jeu vidéo d\'action-RPG et survival horror sorti sur Microsoft Windows.', 88)";
$product4 = mysqli_query($conn, $sql);
if (!$product4) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Elden Ring', 'videogames', 'mmorpg', '2021-02-10', 47.50,'Elden Ring est un jeu vidéo d\'action-RPG développé par FromSoftware et édité par Bandai Namco Entertainment.', 15)";
$product5 = mysqli_query($conn, $sql);
if (!$product5) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('GhostWire', 'videogames', 'action', '2022-05-08', 37.88,'Ghostwire: Tokyo est un futur jeu vidéo d\'action-aventure à la première personne, développé par le studio Tango Gameworks et édité par Bethesda Softworks.', 09)";
$product6 = mysqli_query($conn, $sql);
if (!$product6) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Gotham Knights', 'videogames', 'mmorpg',  '2022-01-15', 65.90,'Gotham Knights est un jeu d\'action-RPG à venir développé par WB Games Montréal et édité par Warner Bros. Interactive Entertainment. Basé sur la franchise DC Comics.', 25)";
$product7 = mysqli_query($conn, $sql);
if (!$product7) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('PayDay2', 'videogames', 'fps', '2022-05-02', 33.90,'Payday 2 est un jeu vidéo en mode coopératif et solo de tir à la première personne développé par Overkill Software.', 86)";
$product8 = mysqli_query($conn, $sql);
if (!$product8) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Rainbow','videogames','fps', '2021-11-10', 52.70,'Développé sur la nouvelle génération de consoles et sur PC, Rainbow Six Siege est le nouvel opus de la franchise de FPS à succès créée par le célèbre studio Ubisoft Montréal.', 30)";
$product9 = mysqli_query($conn, $sql);
if (!$product9) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('SIFU', 'videogames', 'mmorpg', '2022-03-02', 34.55,'Sifu est un jeu vidéo d\'action-aventure de kung-fu développé et édité par le studio français Sloclap, sorti sur Microsoft Windows, PlayStation 4 et PlayStation 5', 100)";
$product10 = mysqli_query($conn, $sql);
if (!$product10) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('DayZ', 'videogames', 'action', '2022-04-10', 22.40,'DayZ est un mod de jeu vidéo basé sur le jeu ARMA II, une simulation militaire développée par Bohemia Interactive.', 14)";
$product11 = mysqli_query($conn, $sql);
if (!$product11) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Escape','videogames','fps', '2022-01-19', 47.45,'Escape From Tarkov est un mmorpg narratif qui mixe les genres FPS/TPS et RPG. Le joueur incarne un ex-mercenaire qui doit survivre dans une Russie ravagée par la guerre.', 45)";
$product12 = mysqli_query($conn, $sql);
if (!$product12) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Farcry', 'videogames', 'action', '2022-06-11', 24.70, 'Far Cry est une série de jeux vidéo de tir à la première personne, nommé d\'après le premier jeu de la série, Far Cry.', 143)";
$product13 = mysqli_query($conn, $sql);
if (!$product13) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Rust', 'videogames', 'mmorpg', '2021-12-20', 60.20, 'Rust est un jeu vidéo d\'aventure et de survie en multijoueur développé et édité par Facepunch Studios.', 89)";
$product14 = mysqli_query($conn, $sql);
if (!$product14) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('AfterMatch', 'videogames', 'mmorpg', '2022-03-11', 70.85,'Dans Aftermath, vous incarnez Charlie Gray, une jeune femme brisée par un grave accident lors d\'une mission spatiale.', 70)";
$product15 = mysqli_query($conn, $sql);
if (!$product15) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('DBZ-1', 'mangas', 'shonen', '1995-01-15', 7.60,'tome 1. Cette collection propose un photomontage des scènes clefs des différents épisodes de cette série, mis en pages comme une véritable bande dessinée.', 200)";
$product16 = mysqli_query($conn, $sql);
if (!$product16) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('DBZ-2', 'mangas', 'shonen', '1995-06-15', 7.60,'tome 2. Cette collection propose un photomontage des scènes clefs des différents épisodes de cette série, mis en pages comme une véritable bande dessinée.', 150)";
$product17 = mysqli_query($conn, $sql);
if (!$product17) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('DBZ1', 'mangas', 'goodies', '1995-10-15', 16.95, 'Superbe figurine goku dragon ball z.', 120)";
$product18 = mysqli_query($conn, $sql);
if (!$product18) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('DBZ2', 'mangas', 'goodies', '1996-01-15', 16.95,'Superbe figurine végéta dragon ball z.', 127)";
$product19 = mysqli_query($conn, $sql);
if (!$product19) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Figurine-Snk', 'mangas', 'goodies', '2019-05-08', 17.89, 'superbe figurine attaque des titans', 72)";
$product20 = mysqli_query($conn, $sql);
if (!$product20) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Figurine-Snk1', 'mangas', 'goodies', '2019-05-08', 17.89, 'superbe figurine attaque des titans', 123)";
$product21 = mysqli_query($conn, $sql);
if (!$product21) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Figurine-Snk2', 'mangas', 'goodies', '2019-05-08', 17.89, 'superbe figurine attaque des titans', 20)";
$product22 = mysqli_query($conn, $sql);
if (!$product22) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Nana-1', 'mangas', 'shojo', '2019-05-08', 6.99, 'tome 1 Nana est un mangas de Ai Yazawa. Il est prépublié à partir de 2000 dans le magazine Cookie de l\'éditeur Shūeisha.', 89)";
$product23 = mysqli_query($conn, $sql);
if (!$product23) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Nana-2', 'mangas', 'shojo', '2019-05-08', 6.99, 'tome 2 Nana est un mangas de Ai Yazawa. Il est prépublié à partir de 2000 dans le magasine Cookie de l\'éditeur Shūeisha.', 26)";



$product24 = mysqli_query($conn, $sql);
if (!$product24) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('High-isle', 'videogames', 'action', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product25 = mysqli_query($conn, $sql);
if (!$product25) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}




$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('the outer world', 'videogames', 'mmorpg', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product26 = mysqli_query($conn, $sql);
if (!$product26) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('monster hunter', 'videogames', 'mmorpg', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product27 = mysqli_query($conn, $sql);
if (!$product27) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('the elder scrolls', 'videogames', 'mmorpg', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product28 = mysqli_query($conn, $sql);
if (!$product28) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('fallout', 'videogames','fps', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product29 = mysqli_query($conn, $sql);
if (!$product29) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}

$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('absolver', 'videogames', 'action', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product30 = mysqli_query($conn, $sql);
if (!$product30) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}

$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('sword art online', 'videogames', 'mmorpg', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product31 = mysqli_query($conn, $sql);
if (!$product31) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('naruto shinobi', 'videogames', 'action', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product32 = mysqli_query($conn, $sql);
if (!$product32) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('elyon', 'videogames', 'mmorpg', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product33 = mysqli_query($conn, $sql);
if (!$product33) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('path of exile', 'videogames', 'action', '2019-05-08', 36.99, 'jeux vidéo aventure.', 26)";



$product34 = mysqli_query($conn, $sql);
if (!$product34) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('casquette capsule corp', 'mangas', 'goodies', '2019-05-08', 16.99, 'casquette.', 26)";



$product35 = mysqli_query($conn, $sql);
if (!$product35) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('casquette dbz m', 'mangas', 'goodies', '2019-05-08', 16.99, 'casquette.', 26)";



$product36 = mysqli_query($conn, $sql);
if (!$product36) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('casquette goku', 'mangas', 'goodies', '2019-05-08', 16.99, 'casquette.', 26)";



$product37 = mysqli_query($conn, $sql);
if (!$product37) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('casquette konoha', 'mangas', 'goodies', '2019-05-08', 16.99, 'casquette.', 26)";



$product38 = mysqli_query($conn, $sql);
if (!$product38) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('casquette one piece', 'mangas', 'goodies', '2019-05-08', 16.99, 'casquette.', 26)";



$product39 = mysqli_query($conn, $sql);
if (!$product39) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('casquette uchiwa', 'mangas', 'goodies', '2019-05-08', 16.99, 'casquette.', 26)";



$product40 = mysqli_query($conn, $sql);
if (!$product40) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}





$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('figurine luffy 1', 'mangas', 'goodies', '2019-05-08', 16.99, 'figurine.', 26)";



$product41 = mysqli_query($conn, $sql);
if (!$product41) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}



$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('figurine luffy 2', 'mangas', 'goodies', '2019-05-08', 16.99, 'figurine.', 26)";



$product42 = mysqli_query($conn, $sql);
if (!$product42) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}





$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('L\'attaque-des-Titans', 'mangas', 'seinen', '2019-05-08', 6.99, 'un seinen mangas écrit et dessiné par Hajime Isayama.', 26)";



$product43 = mysqli_query($conn, $sql);
if (!$product43) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}




$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('L\'attaque-des-Titans-2', 'mangas', 'seinen', '2019-05-08', 6.99, 'un seinen mangas écrit et dessiné par Hajime Isayama.', 26)";



$product44 = mysqli_query($conn, $sql);
if (!$product44) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('L\'attaque-des-Titans-3', 'mangas', 'seinen', '2019-05-08', 6.99, 'un seinen mangas écrit et dessiné par Hajime Isayama.', 26)";



$product45 = mysqli_query($conn, $sql);
if (!$product45) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('L\'attaque-des-Titans-4', 'mangas', 'seinen', '2019-05-08', 6.99, 'un seinen mangas écrit et dessiné par Hajime Isayama.', 26)";



$product46 = mysqli_query($conn, $sql);
if (!$product46) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('L\'attaque-des-Titans-5', 'mangas', 'seinen', '2019-05-08', 6.99, 'un seinen mangas écrit et dessiné par Hajime Isayama.', 26)";



$product47 = mysqli_query($conn, $sql);
if (!$product47) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}



$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Nana-3', 'mangas', 'shojo', '2019-05-08', 6.99, 'un shōjo mangas écrit et dessiné par Hajime Isayama.', 26)";



$product48 = mysqli_query($conn, $sql);
if (!$product48) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}



$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Nana-4', 'mangas', 'shojo', '2019-05-08', 6.99, 'un shōjo mangas écrit et dessiné par Hajime Isayama.', 26)";



$product49 = mysqli_query($conn, $sql);
if (!$product49) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}



$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Nana-5', 'mangas', 'shojo', '2019-05-08', 6.99, 'un shōjo mangas écrit et dessiné par Hajime Isayama.', 26)";



$product50 = mysqli_query($conn, $sql);
if (!$product50) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}

$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('t shirt akatsuki', 'mangas', 'goodies', '2019-05-08', 26.99, 't shirt mangas.', 26)";



$product51 = mysqli_query($conn, $sql);
if (!$product51) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}




$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('t shirt dbz', 'mangas', 'goodies', '2019-05-08', 26.99, 't shirt mangas.', 26)";



$product52 = mysqli_query($conn, $sql);
if (!$product52) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}



$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('t shirt demon slayer', 'mangas', 'goodies', '2019-05-08', 26.99, 't shirt mangas.', 26)";



$product53 = mysqli_query($conn, $sql);
if (!$product53) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}



$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('t shirt snk', 'mangas', 'goodies', '2019-05-08', 26.99, 't shirt mangas.', 26)";



$product54 = mysqli_query($conn, $sql);
if (!$product54) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('nendroid', 'mangas', 'goodies', '2019-05-08', 33.99, 'sacoche naruto.', 26)";



$product55 = mysqli_query($conn, $sql);
if (!$product55) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}


$sql = "INSERT INTO PRODUCT_LIST (name, type, category,  date, price, description, inventory) VALUES ('Katakuri', 'mangas', 'goodies', '2019-05-08', 17.80, 'figurine one piece.', 26)";



$product56 = mysqli_query($conn, $sql);
if (!$product56) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}









echo '<br><br>';
$sql = "INSERT INTO opinion (date, product_id, note, remark) VALUES ('2022-05-12', '3','4', 'A la fois original, réaliste et très aguicheur, c\'est une véritable lettre d\'amour au kung-fu…')";

$opinion = mysqli_query($conn, $sql);
if (!$opinion); {
    echo mysqli_error($conn);
}
echo '<br><br>';
$sql = "INSERT INTO opinion (date, product_id, note, remark) VALUES ('2021-02-21', '17', '5', 'Dès le tome 1, les graphismes sont très matures, dégageant une véritable personnalité. Les arrière-plans sont soignés et travaillés.')";
$opinion2 = mysqli_query($conn, $sql);
if (!$opinion2); {
    echo mysqli_error($conn);
}
echo '<br><br>';
$sql = "INSERT INTO opinion (date, product_id, note, remark) VALUES ('2021-05-04', '5', '2', 'Le jeu est sympa, sans plus.
La difficulté est présente, si on le souhaite on peut partiellement la contourner via l\'utilisation des esprits, de la magie.')";
$opinion3 = mysqli_query($conn, $sql);
if (!$opinion3); {
    echo mysqli_error($conn);
}
echo '<br><br>';

$sql = "INSERT INTO address (city, postal_code, country, address, phone) VALUES ('Lille', '59000', 'France','25 rue du parc','06.54.33.10.25')";
$address1 = mysqli_query($conn, $sql);
if (!$address1) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
echo '<br><br>';

$sql = "INSERT INTO address (city, postal_code, country, address, phone) VALUES ('Dunkerque', '59140', 'France','32 rue jean bart','06.25.10.99.21')";
$address1 = mysqli_query($conn, $sql);
if (!$address1) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}

echo '<br><br>';

$sql = "INSERT INTO address (city, postal_code, country, address, phone) VALUES ('paris', '93400', 'France','12 rue Anselme','07.02.85.50.30')";
$address1 = mysqli_query($conn, $sql);
if (!$address1) {
    echo  mysqli_error($conn);
} else {
    echo "insert reussi";
}
echo '<br><br>';
$sql = "INSERT INTO order_history (user_id, total_price, shipped_date, ordered_date) VALUES ('1', '80.25','2022-05-14', '2022-05-07')";
$ordered1 = mysqli_query($conn, $sql);
if (!$ordered1); {
    echo mysqli_error($conn);
}

$sql = "INSERT INTO order_history (user_id, total_price, shipped_date, ordered_date) VALUES ('2', '130.25', '2022-01-08', '2022-01-01')";
$ordered2 = mysqli_query($conn, $sql);
if (!$ordered2); {
    echo mysqli_error($conn);
}


$sql = "INSERT INTO order_history (user_id, total_price, shipped_date, ordered_date) VALUES ('3', '65.42', '2021-12-15', '2021-12-01')";
$ordered3 = mysqli_query($conn, $sql);
if (!$ordered3); {
    echo mysqli_error($conn);
}

$sql = "INSERT INTO ordered_product (order_id, product_id, price) VALUES (1, 5,'80.25')";
$order1 = mysqli_query($conn, $sql);
if (!$order1); {
    echo mysqli_error($conn);
}

$sql = "INSERT INTO ordered_product (order_id, product_id, price) VALUES (1, 7,'80.25')";
$order1 = mysqli_query($conn, $sql);
if (!$order1); {
    echo mysqli_error($conn);
}

$sql = "INSERT INTO ordered_product (order_id, product_id, price) VALUES (1, 3,'130.25')";
$order1 = mysqli_query($conn, $sql);
if (!$order1); {
    echo mysqli_error($conn);
}


$sql = "INSERT INTO ordered_product (order_id, product_id, price) VALUES (2, 3,'130.25')";
$order2 = mysqli_query($conn, $sql);
if (!$order2); {
    echo mysqli_error($conn);
}





$sql = "INSERT INTO ordered_product (order_id, product_id, price) VALUES (3, 7, '65.42')";
$order3 = mysqli_query($conn, $sql);
if (!$order3); {
    echo mysqli_error($conn);
}

?>



