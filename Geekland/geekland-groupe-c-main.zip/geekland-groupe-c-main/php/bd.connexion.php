<?php

// Connexion

$conn = mysqli_connect('localhost', 'root', '', 'geekland');
mysqli_set_charset($conn, 'utf8');
if ($conn->connect_error) {
    die('Error of connexion');
} 