<?php
include('bd.connexion.php');


// DELETE TABLE
// $sql="DROP TABLE IF EXISTS users";
// if ($conn->query($sql) === TRUE) {
//   echo "<br> Table delete successfully";
// } else {
//   echo "Error: " . $sql . "<br>" . $conn->error;
// }



mysqli_query($conn,'set names "utf8" ');

// Insert into users
// User 1
$sql = "INSERT INTO users (name, lastname, email, password, city_id, valide_user)
VALUES ('Klowa', 'Youla', 'KlowaYoula@gmail.com', '123456', 2, 'yes')";

$users1 = mysqli_query($conn,$sql);
if (!$users1);
{
    echo mysqli_error($conn);
}

  
// User 2
  $sql = "INSERT INTO users (name, lastname, email, password, city_id, valide_user)
VALUES ('dumoulin', 'Nicolas', 'testnicolas@gmail.com', '123456', 1, 'yes')";

$users2 = mysqli_query($conn,$sql);
if (!$users2);
{
    echo mysqli_error($conn);
}



// User 3
$sql = "INSERT INTO users (name, lastname, email, password, city_id, valide_user)
VALUES ('dalo', 'éric', 'testdalo@gmail.com', '123456', 3, 'yes')";


$users3 = mysqli_query($conn,$sql);
if (!$users3);
{
    echo mysqli_error($conn);
}


?>