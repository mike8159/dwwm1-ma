<?php

// Connexion
include ('bd.connexion.php');

// Table users

$requete = 'CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    lastname VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    city_id INT,
    valide_user VARCHAR(50) NOT NULL)';


$req = mysqli_query($conn, $requete);


echo '<br> Table users create ';



// Table Opinion

$requete2 = 'CREATE TABLE IF NOT EXISTS opinion (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    date VARCHAR(50) NOT NULL,
    product_id INT,
    note TINYINT,
    remark VARCHAR(191) NOT NULL)';

$req = mysqli_query($conn, $requete2);


echo '<br> Table opinion create ';


// Table ordered_product

$requete3 = 'CREATE TABLE IF NOT EXISTS ordered_product (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    price DOUBLE)';

$req = mysqli_query($conn, $requete3);


echo '<br> Table ordered_product create ';


// Table address

$requete4 = 'CREATE TABLE IF NOT EXISTS address (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    city VARCHAR(50) NOT NULL,
    postal_code VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL,
    address VARCHAR(50) NOT NULL,
    phone VARCHAR(50) NOT NULL)';

$req = mysqli_query($conn, $requete4);


echo '<br> Table address create ';


// Table order_history

$requete5 = 'CREATE TABLE IF NOT EXISTS order_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_price DOUBLE,
    shipped_date DATE,
    ordered_date DATE)';

$req = mysqli_query($conn, $requete5);
echo '<br> Table order_history create ';


// Table product_list

$requete6 = 'CREATE TABLE IF NOT EXISTS product_list (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    type  VARCHAR(50) NOT NULL DEFAULT "videogames",
    category VARCHAR(50) NOT NULL DEFAULT "mangas",
    date DATE,
    price DOUBLE,
    description VARCHAR(191) NOT NULL,
    inventory INT)';

$req = mysqli_query($conn, $requete6);


echo '<br> Table product_list create ';
echo mysqli_error($conn);


?>
